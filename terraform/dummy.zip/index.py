import boto3
import json

s3 = boto3.client('s3')

def handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    try:
        # Extract bucket name from CloudTrail event
        bucket_name = event['detail']['requestParameters']['bucketName']
        print(f"Detected Public Access Block modification on bucket: {bucket_name}")
        
        # Enforce public access block
        s3.put_public_access_block(
            Bucket=bucket_name,
            PublicAccessBlockConfiguration={
                'BlockPublicAcls': True,
                'IgnorePublicAcls': True,
                'BlockPublicPolicy': True,
                'RestrictPublicBuckets': True
            }
        )
        print(f"Successfully reinstated Block Public Access (Self-Healing) for bucket: {bucket_name}")
    except Exception as e:
        print(f"Error executing remediation: {str(e)}")
        raise e
    return {'statusCode': 200, 'body': 'Remediation executed successfully'}
