# Event-Driven Async File Upload Walkthrough

We have successfully migrated the file upload flow from a synchronous blocking process to an asynchronous, Event-Driven Architecture. This completely eliminates the 29s timeout limitation of the API Gateway, enabling long-running tasks like processing 5-10 page PDF bank statements through Textract and Bedrock AI.

## Architecture Changes

The heavy lifting (OCR and AI Categorization) has been decoupled from the API request cycle.

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Frontend as React Frontend
    participant API as API Gateway + Backend Lambda
    participant DB as DynamoDB
    participant S3 as S3 Bucket
    participant Processor as Processor Lambda
    participant AI as Bedrock AI

    User->>Frontend: Upload Bank Statement (PDF/CSV)
    Frontend->>API: POST /upload (File data)
    API->>S3: Save file (PutObject)
    API->>DB: Create JOB record (Status: PENDING)
    API-->>Frontend: Return job_id instantly (< 1s)
    
    note right of Frontend: Frontend displays floating "Processing Pill"

    S3--)Processor: Trigger S3 Event (s3:ObjectCreated:*)
    Processor->>DB: Update JOB status (Status: PROCESSING)
    
    Frontend->>API: Poll GET /upload/status/{job_id} (Every 3s)
    API->>DB: Read JOB record
    DB-->>API: Return JOB status
    API-->>Frontend: Return {status: "PROCESSING"}

    Processor->>Processor: Extract text (Textract / PyPDF)
    Processor->>AI: Send text for categorization
    AI-->>Processor: Return categorized transactions + confidence
    Processor->>DB: Store transactions
    Processor->>DB: Update JOB status (Status: COMPLETED, needs_review: [...])
    
    Frontend->>API: Poll GET /upload/status/{job_id}
    API-->>Frontend: Return {status: "COMPLETED", needs_review: [...]}
    
    note right of Frontend: Frontend displays Success Toast Notification
    
    User->>Frontend: Clicks Toast or auto-triggers
    Frontend->>Frontend: Show "Manual Review" Modal (if low confidence)
```

1.  **Fast API Response**: When a user uploads a file, the `handle_upload` endpoint simply saves the raw file to S3 and creates a `JOB` tracking record in DynamoDB (with status `PENDING`). The API returns almost instantly (< 1s) with a `job_id`.
2.  **Event-Driven Trigger**: The S3 bucket is configured with a notification that triggers whenever a new object is created (`s3:ObjectCreated:*`).
3.  **Background Processor Lambda**: This notification triggers a newly created Lambda function (`budgetbot-hackathon-file-processor`). This Lambda is dedicated to background tasks:
    *   It has a timeout of **5 minutes** (300 seconds) and **1536MB of RAM**, allowing plenty of time for Textract OCR and Bedrock LLM processing.
    *   It reads the `JOB` record, updates it to `PROCESSING`, performs the extraction and AI categorization, stores the final transactions, and marks the job as `COMPLETED`.
4.  **Frontend Polling**: The React frontend uses a new `UploadContext` to poll the `/upload/status/{job_id}` API every 3 seconds while a job is active.

## UI / UX Enhancements

The user experience has been drastically improved to handle asynchronous workflows smoothly:

*   **Non-Blocking UI**: The user is no longer locked on the Overview page while a file processes. They can navigate away, read the Chat tab, or view their existing Transactions.
*   **Processing Pill**: A sleek, floating processing pill appears at the bottom of the screen to indicate that background tasks are running.
*   **Toast Notifications**: Once the background processor Lambda finishes its work, a beautiful slide-in toast notification alerts the user:
    *   **Success**: Displays how many transactions were categorized. Clicking the notification directs the user straight to the Transactions page to view their new data.
    *   **Error**: Alerts the user if processing failed (e.g., corrupted file).

## Verification

*   **AWS Infrastructure**: Verified that `terraform apply` created the `aws_lambda_function.file_processor` and the `aws_s3_bucket_notification.uploads_notification` successfully.
*   **Lambda Deployment**: The new `processor.py` handler was packaged and deployed correctly to AWS.
*   **Frontend**: The React application has been rebuilt and synced to the S3 bucket (`budgetbot-hackathon-frontend-873fca3d`).

The user can now upload complex PDF bank statements without fear of API timeouts, enjoying a smooth, modern, and non-blocking application experience.
